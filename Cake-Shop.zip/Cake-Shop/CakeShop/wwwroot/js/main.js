import * as JQuery from 'jquery/dist/jquery.js';
import 'jquery-validation/dist/jquery.validate.js';
import 'jquery-validation-unobtrusive/dist/jquery.validate.unobtrusive.js';
import 'popper.js/dist/popper.js';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import 'font-awesome/css/font-awesome.css';

import '../css/Style.css';

window.$ = window.jQuery = JQuery;

