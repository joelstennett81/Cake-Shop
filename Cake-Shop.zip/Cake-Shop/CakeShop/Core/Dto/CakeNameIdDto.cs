﻿namespace CakeShop.Core.Dto
{
    public class CakeNameIdDto
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
}
